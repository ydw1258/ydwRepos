#include "Player.h"
#include "Map.h"
#include <conio.h>

Player::Player()
{
}


Player::~Player()
{
}

void Player::Init(Map* _pMap)
{
	pMap = _pMap;
	pMap->SetPlayer(playerX, playerY);
}

bool Player::OperateInput()
{
	char ch = getch();

	pMap->SetEmpty(playerX , playerY);

	switch (ch)
	{
	case 'w':
		if (pMap->isTileWall(playerX , playerY - 1))
			playerY--;
		break;
	case 's':
		if (pMap->isTileWall(playerX, playerY + 1))
			playerY++;
		break;
	case 'a':
		if (pMap->isTileWall(playerX - 1, playerY))
			playerX--;
		break;
	case 'd':
		if (pMap->isTileWall(playerX + 1, playerY))
			playerX++;
		break;
	}

	pMap->SetPlayer(playerX, playerY);

	return false;
}
