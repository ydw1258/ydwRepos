#include <iostream>
#include <conio.h>
#include <vector>
#include "Map.h"
#include "Player.h"
using namespace std;

/*
template <typename T , typename T2> 
T sum(T a, T2 b)
{
	return a + b;
}*/

int main()
{
	//sum(1, 3);
	int arr[10];
	vector<STUDENT*> vec;
	vector<int> vec;
	vec.reserve(1024);
	vec.push_back(10);
	vec.push_back(20);
	vec.push_back(30);

	cout << vec[0] << endl;

	for (auto iter = vec.begin(); iter != vec.end(); iter++)
	{
		cout << *iter << endl;
	}

	for (vector<int>::iterator iter = vec.begin(); 
		iter != vec.end(); iter++)
	{

	}
	
	for(int i = 0 ; i < vec.size() ; i++)
		cout << vec[i] << endl;

	int a = 0;
	Map map;
	Player player;

	map.Init();
	player.Init(&map);

	map.DrawMap();
	while (true)
	{
		if (player.OperateInput())
			break;

		//Update

		map.DrawMap();
	}

	return 0;
}