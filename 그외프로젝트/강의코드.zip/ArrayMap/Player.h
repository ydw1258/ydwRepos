#pragma once//��ǥ��
#ifndef PLAYER_H
#define PLAYER_H
#include "Map.h"

class Map;
class Player
{
private:
	int playerX = WIDTH / 2;
	int playerY = HEIGHT / 2;
	Map* pMap;
public:
	void Init(Map* _pMap);
	bool OperateInput();

	Player();
	~Player();
};

#endif