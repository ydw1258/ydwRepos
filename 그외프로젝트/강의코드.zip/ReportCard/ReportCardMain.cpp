#include <iostream>
#include <stdio.h>
using namespace std;

struct student
{
	int no;
	char szName[256];
	int kor;
	int eng;
	int math;
};

void inputStudent(student st[], int& iCurStudent)
{
	st[iCurStudent].no = iCurStudent + 1;
	cout << "�̸�" << endl;
	cin >> st[iCurStudent].szName;
	cout << "����" << endl;
	cin >> st[iCurStudent].kor;
	cout << "����" << endl;
	cin >> st[iCurStudent].eng;
	cout << "����" << endl;
	cin >> st[iCurStudent].math;
	iCurStudent++;
}

void outputStudent(student st[], int iCurStudent)
{
	cout << "��ȣ\t�̸�\t����\t����\t����\t����\t���" << endl;
	for (int i = 0; i < iCurStudent; i++)
	{
		float fSum = st[i].kor + st[i].eng + st[i].math;
		float fAvg = fSum / 3;
		cout << st[i].no << "\t" << st[i].szName << "\t" <<
			st[i].kor << "\t" << st[i].eng << "\t" <<
			st[i].math << "\t" <<
			fSum << "\t" << fAvg << endl;
	}
}

void saveStudent(student st[], int iCurStudent)
{
	FILE* pFile = fopen("save.txt", "w");
	fprintf(pFile, "%d\n", iCurStudent);
	for (int i = 0; i < iCurStudent; i++)
	{
		fprintf(pFile, "%d %s %d %d %d\n", st[i].no, st[i].szName,
			st[i].kor, st[i].eng, st[i].math);
	}
	fclose(pFile);
}

void printMenu()
{
	cout << "1.�Է�" << endl;
	cout << "2.���" << endl;
	cout << "3.����" << endl;
	cout << "4.����" << endl;
}

int main()
{	
	student st[3];
	int iCurStudent = 0;

	FILE* pFile = fopen("save.txt", "r");
	if (pFile != nullptr)
	{
		fscanf(pFile, "%d\n", &iCurStudent);
		for (int i = 0; i < iCurStudent; i++)
		{
			fscanf(pFile, "%d %s %d %d %d\n", &st[i].no, st[i].szName,
				&st[i].kor, &st[i].eng, &st[i].math);
		}
		fclose(pFile);
	}
	

	while (true)
	{
		int input = 0;

		printMenu();

		cin >> input;

		if (input == 1)
		{
			inputStudent(st , iCurStudent);
		}
		else if (input == 2)
		{
			outputStudent(st, iCurStudent);
		}
		else if (input == 3)
		{
			saveStudent(st, iCurStudent);
		}
		else if (input == 4)
		{
			break;
		}
	}

	return 0;
}