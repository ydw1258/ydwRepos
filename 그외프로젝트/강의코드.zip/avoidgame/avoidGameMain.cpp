#include <iostream>
#include <fstream>
using namespace std;

//int map[20][20];

//1�Է�
//2���
//3����
//4����

int main()
{
	int a = 0;
	switch (a)
	{
	case 1:
		break;
	}

	/*
	ofstream outfile("aasd.txt" , ios::out);
	outfile << "asdsad" << endl;
	outfile.close();*/
	
	/*
	char szBuf[256];
	ifstream inFile("a.txt" , ios::in);
	inFile >> szBuf;
	cout << szBuf;
	inFile.close();*/

	//C
	FILE* p = fopen("a.txt", "w");

	fprintf(p, "%d", 1);
	fprintf(p, "%d", 2);

	//int a = 0;
	//fscanf(p, "%d", &a);
	//cout << a << endl;
	//fscanf(p, "%d", &a);
	//cout << a << endl;

	//fseek(p, 4, SEEK_CUR); SEEK_END SEEK_SET

	//char szBuf[256] = "asdsadads";
	//fread(szBuf, sizeof(char), 256, p);

	//fwrite(map, sizeof(int), 20*20, p);
	

	//cout << szBuf << endl;

	fclose(p); 

	return 0;
}