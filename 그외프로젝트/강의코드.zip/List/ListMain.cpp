#include <iostream>
using namespace std;

struct Node
{
	int value;
	Node* pNext;
};

Node* deleteNode(Node* pStart, int nPlace)
{
	return NULL;
}

Node* insertNode(Node* pStart, Node* pInsert, int nPlace)
{
	return NULL;
}

enum CLASS
{
	WARRIOR = 1 >> 1,
	ARCHOR = 1 >> 2,
	WIZARD 
};

//n! == n * (n - 1)!
//1! == 1
int factorial(int n)
{
	if (n == 1)
		return 1;
	else
		return n * factorial(n - 1);
}

int sum(int a, int b = 0)
{
	return a + b;
}

void print()
{
	cout << "print" << endl;
}

typedef void(*FN_TYPE)();

int main()
{






	//void(*pfun)();
	//pfun = &print;
	//(*pfun)();

	FN_TYPE pfun;
	pfun = print;
	pfun();

	//cout << factorial(4) << endl;

	/*
	//0�� �Է��Ҷ����� �Է��� �ް� ���� �Է��� �״�� ���
	Node* pStart = NULL;
	while (true)
	{
		int input = 0;
		cin >> input;

		if (input == 0)
			break;

		Node* pNew = new Node();
		pNew->value = input;
		pNew->pNext = NULL;

		if (pStart == NULL)
		{
			pStart = pNew;
		}
		else
		{
			Node* pLast = pStart;
			while (true)
			{
				if (pLast->pNext == NULL)
					break;

				pLast = pLast->pNext;
			}
			pLast->pNext = pNew;
		}
	}

	pStart = deleteNode(pStart, 3);

	Node* pCur = pStart;
	while (true)
	{
		cout << pCur->value << endl;
		if (pCur->pNext == NULL)
			break;

		pCur = pCur->pNext;
	}

	pCur = pStart;
	while (true)
	{
		if (pCur == NULL)
			break;

		Node* pDel = pCur;
		pCur = pCur->pNext;
		delete pDel;
	}*/


	//���� �Ѱ� �Է��� �����ð� EX>5 
	//5���� ���� ������ �Ҵ��ϰ� 
	//5�� �Է� �ް� �״�� ���

	/*
	int num = 0;
	cin >> num;

	int* p = new int[num];

	for (int i = 0; i < num; i++)
	{
		cin >> p[i];
	}

	for (int i = 0; i < num; i++)
	{
		cout << p[i] << endl;
	}

	delete[] p;
	*/

	/*
	int a = 0;//stack
	int *p = new int;
	int *arr = new int[4];

	delete[] arr;
	delete p;*/


	return 0;
}