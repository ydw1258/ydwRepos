#include <iostream>
#include <fstream>
using namespace std;

int getCharCount(const char* szLine , int len , char ch)
{
	int iCount = 0;
	while (true)
	{
		szLine = strchr(szLine, ch);
		if (szLine == nullptr)
			break;

		szLine++;
		iCount++;
	}

	return iCount;
}

int getCharPoint(const char* szLine, int len , char ch , int iStart)
{
	for (int i = iStart; i < len; i++)
	{
		if (szLine[i] == ch)
			return i;
	}

	return -1;
}

char** getSpliteText(const char* szLine , int len, char ch)
{
	int iCount = getCharCount(szLine, len ,ch) + 1;

	int iStartPt = 0;
	int iEnd = 0;
	char** szName = new char*[iCount];
	for (int i = 0; i < iCount; i++)
	{
		szName[i] = new char[256];
		iEnd = getCharPoint(szLine, len, ch, iStartPt);
		if (iEnd == -1)
			iEnd = len;

		memcpy(szName[i], &szLine[iStartPt], iEnd - iStartPt);
		szName[i][iEnd - iStartPt] = NULL;

		iStartPt = iEnd + 1;
	}

	return szName;
}

int main()
{
	ifstream inputFile("data.csv");

	char szLineName[256];
	inputFile.getline(szLineName, 256);
	int iTotalCol = getCharCount(szLineName, strlen(szLineName), ',') + 1;
	char** spliteName = getSpliteText(szLineName, strlen(szLineName), ',');

	char szLineVari[256];
	inputFile.getline(szLineVari, 256);
	char** spliteVari = getSpliteText(szLineVari, strlen(szLineVari), ',');

	char szLineExplain[256];
	inputFile.getline(szLineExplain, 256);
	char** spliteExplain = getSpliteText(szLineExplain, strlen(szLineExplain), ',');

	inputFile.close();

	ofstream outFile("data.h");

	outFile << "struct data\n";
	outFile << "{\n";

	for (int i = 0; i < iTotalCol; i++)
	{
		outFile << "\t" << spliteVari[i] << " " << spliteName[i] << ";//" << spliteExplain[i] << "\n";
	}
	
	outFile << "}\n";

	outFile.close();

	for (int i = 0; i < iTotalCol; i++)
	{
		delete[] spliteName[i];
		delete[] spliteVari[i];
		delete[] spliteExplain[i];
	}

	delete[] spliteName;
	delete[] spliteVari;
	delete[] spliteExplain;

	cout << szLineName << endl;
	cout << szLineVari << endl;
	cout << szLineExplain << endl;

	return 0;
}