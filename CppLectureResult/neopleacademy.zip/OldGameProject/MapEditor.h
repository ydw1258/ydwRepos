#pragma once
class MapEditor
{
public:
	MapEditor();
	~MapEditor();
};

