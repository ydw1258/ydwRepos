#pragma once
class Item
{
public:
	Item();
	~Item();
};

