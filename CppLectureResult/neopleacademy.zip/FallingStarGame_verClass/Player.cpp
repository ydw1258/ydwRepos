#include "Player.h"

Player::Player()
{
}

void Player::Init(Map* _pMap)
{
	pMap = _pMap;
	pMap->SetPlayer;
}

Player::~Player()
{
}
bool Player::OperateInput()
{

}