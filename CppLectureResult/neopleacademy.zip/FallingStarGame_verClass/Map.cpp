#include "Map.h"

Map::Map()
{
	for (int i = 0; i < HEIGHT; i++)
	{
		for (int j = 0; j < WIDTH; j++)
		{
			map[i][j] = EMPTY;
		}
	}
}
void Map::DrawMap()
{
	for (int i = 0; i < HEIGHT; i++)
	{
		for (int j = 0; j < WIDTH; j++)
		{
			if ()
			{

			}
			else
			{

			}
		}
	}
}
inline void Map::SetEmpty(int x, int y)
{

}
Map::~Map()
{
	
}
