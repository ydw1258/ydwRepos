#pragma once
class GameManager
{
public:
	GameManager();

	~GameManager();
};

