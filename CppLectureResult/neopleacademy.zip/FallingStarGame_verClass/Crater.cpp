#include "Crater.h"

Crater::Crater()
{
	
}
Crater::~Crater()
{
}
void Crater::move()
{
	y += speed;
}